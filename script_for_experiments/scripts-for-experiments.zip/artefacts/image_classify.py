"""
Author : R K Sharath Kumar
"""

# Import all dependencies
import os
import numpy as np
import keras
from keras.models import Model
import keras.backend as K
import keras.regularizers as R
import keras.constraints as C
from keras.layers import *
from keras.optimizers import *
import data_preprocessing as helper
from keras.callbacks import TensorBoard, Callback
import json
from os import environ
from emetrics import EMetrics



model_filename = "imageclassifier.h5"

# writing the train model and getting input data

if environ.get('RESULT_DIR') is not None:
    output_model_folder = os.path.join(os.environ["RESULT_DIR"], "model")
    output_model_path = os.path.join(output_model_folder, model_filename)
else:
    output_model_folder = "model"
    output_model_path = os.path.join("model", model_filename)

os.makedirs(output_model_folder, exist_ok=True)

#writing metrics
if environ.get('JOB_STATE_DIR') is not None:
    tb_directory = os.path.join(os.environ["JOB_STATE_DIR"], "logs", "tb", "test")
else:
    tb_directory = os.path.join("logs", "tb", "test")

os.makedirs(tb_directory, exist_ok=True)
tensorboard = TensorBoard(log_dir=tb_directory)


config_file = "config.json"

if os.path.exists(config_file):
    with open(config_file, 'r') as f:
        json_obj = json.load(f)
    learning_rate = json_obj["learning_rate"]
    batch_size = json_obj["batch_size"]
    num_epochs = json_obj["num_epochs"]

else:
    learning_rate = 0.001
    batch_size = 16
    num_epochs = 5


def getCurrentSubID():
    if "SUBID" in os.environ:
        return os.environ["SUBID"]
    else:
        return None

class HPOMetrics(keras.callbacks.Callback):
    def __init__(self):
        self.emetrics = EMetrics.open(getCurrentSubID())

    def on_epoch_end(self, epoch, logs={}):
        train_results = {}
        test_results = {}

        for key, value in logs.items():
            if 'val_' in key:
                test_results.update({key: value})
            else:
                train_results.update({key: value})

        print('EPOCH ' + str(epoch))
        self.emetrics.record("train", epoch, train_results)
        self.emetrics.record(EMetrics.TEST_GROUP, epoch, test_results)

    def close(self):
        self.emetrics.close()

# Perform data pre-processing
defined_metrics = []
decay = 0.100000
beta_1 = 0.900000
beta_2 = 0.999000

ImageData_1_params = {
    "train_dataset": "artefacts/train.pkl",
    "val_dataset": "artefacts/validation.pkl",
    "test_dataset": "artefacts/test.pkl",
    "validation_split": 0.3,
    "test_split": 0.1,
    "rows": 32,
    "cols": 32,
    "dim_ordering": "channels_last",
    "dbformat": "Python Pickle",
    "num_classes": 4
}
ImageData_1_data = helper.image_data_handler(ImageData_1_params)
train_x = ImageData_1_data["train_x"]
train_y = ImageData_1_data["train_y"]
val_x = ImageData_1_data["val_x"]
val_y = ImageData_1_data["val_y"]
test_x = ImageData_1_data["test_x"]
test_y = ImageData_1_data["test_y"]
labels = ImageData_1_data["labels"]
ImageData_1_shape = train_x.shape[1:]


# Define network architecture
ImageData_1 = Input(shape=ImageData_1_shape)
Convolution2D_2 = Conv2D(
    64, (3, 3),
    data_format="channels_last",
    strides=(1, 1),
    padding="valid",
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="glorot_uniform",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None)(ImageData_1)
ReLU_7 = Activation("relu")(Convolution2D_2)
Pooling2D_3 = MaxPooling2D(
    pool_size=(2, 2),
    strides=(1, 1),
    padding="valid",
    data_format="channels_last")(ReLU_7)
Dropout_4 = Dropout(0.25)(Pooling2D_3)
Convolution2D_5 = Conv2D(
    64, (3, 3),
    data_format="channels_last",
    strides=(1, 1),
    padding="valid",
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="glorot_uniform",
    kernel_regularizer=R.l1_l2(0.01),
    bias_regularizer=R.l1_l2(0.01),
    activity_regularizer=R.l1_l2(0.01),
    kernel_constraint=C.non_neg(),
    bias_constraint=C.non_neg())(Dropout_4)
ReLU_8 = Activation("relu")(Convolution2D_5)
Pooling2D_6 = MaxPooling2D(
    pool_size=(2, 2),
    strides=(1, 1),
    padding="valid",
    data_format="channels_last")(ReLU_8)
Dropout_9 = Dropout(0.25)(Pooling2D_6)
Convolution2D_10 = Conv2D(
    64, (3, 3),
    data_format="channels_last",
    strides=(1, 1),
    padding="valid",
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="glorot_uniform",
    kernel_regularizer=R.l1_l2(0.01),
    bias_regularizer=R.l1_l2(0.01),
    activity_regularizer=R.l1_l2(0.01),
    kernel_constraint=C.non_neg(),
    bias_constraint=C.non_neg())(Dropout_9)
ReLU_12 = Activation("relu")(Convolution2D_10)
Pooling2D_11 = MaxPooling2D(
    pool_size=(2, 2),
    strides=(1, 1),
    padding="valid",
    data_format="channels_last")(ReLU_12)
Dropout_13 = Dropout(0.25)(Pooling2D_11)
Convolution2D_14 = Conv2D(
    64, (3, 3),
    data_format="channels_last",
    strides=(1, 1),
    padding="valid",
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="glorot_uniform",
    kernel_regularizer=R.l1_l2(0.01),
    bias_regularizer=R.l1_l2(0.01),
    activity_regularizer=R.l1_l2(0.01),
    kernel_constraint=C.non_neg(),
    bias_constraint=C.non_neg())(Dropout_13)
ReLU_16 = Activation("relu")(Convolution2D_14)
Pooling2D_15 = MaxPooling2D(
    pool_size=(2, 2),
    strides=(1, 1),
    padding="valid",
    data_format="channels_last")(ReLU_16)
Dropout_17 = Dropout(0.25)(Pooling2D_15)
Flatten_18 = Flatten()(Dropout_17)
Dense_19 = Dense(
    512,
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="glorot_uniform",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None)(Flatten_18)
ReLU_20 = Activation("relu")(Dense_19)
Dropout_21 = Dropout(0.5)(ReLU_20)
Dense_25 = Dense(
    4,
    use_bias=True,
    kernel_initializer="glorot_uniform",
    bias_initializer="glorot_uniform",
    kernel_regularizer=None,
    bias_regularizer=None,
    activity_regularizer=None,
    kernel_constraint=None,
    bias_constraint=None)(Dropout_21)
Softmax_22 = Activation("softmax")(Dense_25)
defined_loss = "categorical_crossentropy"
defined_metrics.append("accuracy")

model_inputs = [ImageData_1]
model_outputs = [Softmax_22]
model = Model(inputs=model_inputs, outputs=model_outputs)


#Define optimizer
optim = Adam(lr=learning_rate, beta_1=beta_1, beta_2=beta_2, decay=decay)

model.summary()

# Perform training and other misc. final steps
model.compile(loss=defined_loss, optimizer=optim, metrics=defined_metrics)
train_y = [train_y] * len(model_outputs)
val_y   = [val_y]   * len(model_outputs)
test_y  = [test_y]  * len(model_outputs)

hpo = HPOMetrics()

prep_model = model.fit(
        train_x,
        train_y,
        batch_size=batch_size,
        epochs=num_epochs,
        verbose=1,
        validation_data=(val_x, val_y),
        shuffle=True,
        callbacks=[tensorboard, hpo])

hpo.close()

#print("Training history:" + str(prep_model.history))

test_scores = model.evaluate(test_x, test_y, verbose=1)
print('Test Accuracy:', test_scores[1])
print('Test Loss:', test_scores[0])
model.save(output_model_path)
print("Model saved in file: %s" % output_model_path)
