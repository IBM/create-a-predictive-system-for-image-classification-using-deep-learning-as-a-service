"""
Author : R K Sharath Kumar
"""

# Import all dependencies
import os
import numpy as np
import keras
from keras.models import Model
import keras.backend as K
import keras.regularizers as R
import keras.constraints as C
from keras.layers import *
from keras.optimizers import *
import data_preprocessing as helper
from keras.callbacks import TensorBoard, Callback
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, Activation, BatchNormalization
from keras.optimizers import rmsprop
import json
import time
from os import environ
from emetrics import EMetrics



model_filename = "imageclassifier.h5"

# writing the train model and getting input data

if environ.get('RESULT_DIR') is not None:
    output_model_folder = os.path.join(os.environ["RESULT_DIR"], "model")
    output_model_path = os.path.join(output_model_folder, model_filename)
else:
    output_model_folder = "model"
    output_model_path = os.path.join("model", model_filename)

os.makedirs(output_model_folder, exist_ok=True)

#writing metrics
if environ.get('JOB_STATE_DIR') is not None:
    tb_directory = os.path.join(os.environ["JOB_STATE_DIR"], "logs", "tb", "test")
else:
    tb_directory = os.path.join("logs", "tb", "test")

os.makedirs(tb_directory, exist_ok=True)
tensorboard = TensorBoard(log_dir=tb_directory)


config_file = "config.json"

if os.path.exists(config_file):
    with open(config_file, 'r') as f:
        json_obj = json.load(f)
    learning_rate = json_obj["learning_rate"]
    batch_size = json_obj["batch_size"]
    num_epochs = json_obj["num_epochs"]

else:
    learning_rate = 0.0001
    batch_size = 3
    num_epochs = 5


def getCurrentSubID():
    if "SUBID" in os.environ:
        return os.environ["SUBID"]
    else:
        return None

class HPOMetrics(keras.callbacks.Callback):
    def __init__(self):
        self.emetrics = EMetrics.open(getCurrentSubID())

    def on_epoch_end(self, epoch, logs={}):
        train_results = {}
        test_results = {}

        for key, value in logs.items():
            if 'val_' in key:
                test_results.update({key: value})
            else:
                train_results.update({key: value})

        print('EPOCH ' + str(epoch))
        self.emetrics.record("train", epoch, train_results)
        self.emetrics.record(EMetrics.TEST_GROUP, epoch, test_results)

    def close(self):
        self.emetrics.close()

# Perform data pre-processing
defined_metrics = []

ImageData_1_params = {
    "train_dataset": "artefacts/train.pkl",
    "val_dataset": "artefacts/validation.pkl",
    "test_dataset": "artefacts/test.pkl",
    "validation_split": 0,
    "test_split": 0,
    "rows": 224,
    "cols": 224,
    "dim_ordering": "channels_last",
    "dbformat": "Python Pickle",
    "num_classes": 3
}
ImageData_1_data = helper.image_data_handler(ImageData_1_params)
train_x = ImageData_1_data["train_x"]
train_y = ImageData_1_data["train_y"]
val_x = ImageData_1_data["val_x"]
val_y = ImageData_1_data["val_y"]
test_x = ImageData_1_data["test_x"]
test_y = ImageData_1_data["test_y"]
labels = ImageData_1_data["labels"]
ImageData_1_shape = train_x.shape[1:]


# Define network architecture

IMAGE_WIDTH=224
IMAGE_HEIGHT=224
IMAGE_SIZE=(IMAGE_WIDTH, IMAGE_HEIGHT)
IMAGE_CHANNELS=3 

model = Sequential()

model.add(Conv2D(64, (3, 3), activation='relu', input_shape=(IMAGE_WIDTH, IMAGE_HEIGHT, IMAGE_CHANNELS)))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(rate=0.15))

model.add(Conv2D(128, (3, 3), activation='relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(rate=0.20))

model.add(Flatten())
model.add(Dense(256, activation='relu'))
model.add(BatchNormalization())
model.add(Dropout(rate=0.35))
model.add(Dense(3, activation='softmax'))


#Define optimizer
optim = rmsprop(lr=0.0001)

model.summary()

# Perform training and other misc. final steps
model.compile(loss='categorical_crossentropy', optimizer=optim, metrics=['accuracy'])

hpo = HPOMetrics()

start = time.time()
prep_model = model.fit(
        train_x,
        train_y,
        batch_size=batch_size,
        epochs=num_epochs,
        verbose=1,
        validation_data=(val_x, val_y),
        shuffle=True,
        callbacks=[tensorboard, hpo])

print("> Completion Time : ", time.time() - start)

hpo.close()

#print("Training history:" + str(prep_model.history))

test_scores = model.evaluate(test_x, test_y, verbose=1)
print('Test Accuracy:', test_scores[1])
print('Test Loss:', test_scores[0])
model.save(output_model_path)
print("Model saved in file: %s" % output_model_path)
